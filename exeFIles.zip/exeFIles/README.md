Go Image cutter by Seung jin Yu

how to run

./imageCutter[OS] [options:]

ex)

./imageCutterAmd64Linux 150-200 300-400 500-600

put the source image files on ./sourcedata directory

and the results will come out in ./resultdata
